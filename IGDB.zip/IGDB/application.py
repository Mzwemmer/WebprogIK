from igdb_api_python.igdb import igdb as igdb
import time, os
from helpers import *
import json

game = 1942
url = 'https://api-v3.igdb.com/games/'
headers = {'user-key': '663bdc9cdfcbb5aaae5a2a8a14b4d70a'}
r = requests.get(url, headers = headers, json = {"key":"value"})
print(r.json())